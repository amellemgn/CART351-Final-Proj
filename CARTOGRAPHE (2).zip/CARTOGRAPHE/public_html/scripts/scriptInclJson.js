// SVG.on(document, 'DOMContentLoaded', function() {

function displayHexes(response){
}

// });
index = response.length - 1;
huevalue = response[index].color1;
huevalue2 = response[index].color2;
xRange = response[index].xPos;
yRange = response[index].yPos;
inputText = response[index].userText;
count = response[index].userID;
