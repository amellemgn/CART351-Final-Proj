window.onload = function(){
  let hexobjA = new HexObj(50,50,50,0);
  hexobjA.display();
  hexobjA.appendGradient();
  document.getElementById(0).style.left = "100px";
  document.getElementById(0).style.top = "100px";

  let hexobjB = new HexObj(50,50,50,1);
  hexobjB.display();
  hexobjB.appendGradient();


document.getElementById(1).style.left = "200px";
document.getElementById(1).style.top = "100px";

let hexobjC = new HexObj(50,50,50,2);
hexobjC.display();
hexobjC.appendGradient();

document.getElementById(2).style.left = "100px";
document.getElementById(2).style.top = "200px";

let hexobjD = new HexObj(50,50,50,3);
hexobjD.display();
hexobjD.appendGradient();


document.getElementById(3).style.left = "200px";
document.getElementById(3).style.top = "200px";

document.getElementById(3).addEventListener('mousedown',function(){
  console.log("clicked");
})


}
